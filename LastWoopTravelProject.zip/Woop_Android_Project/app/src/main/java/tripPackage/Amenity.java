package tripPackage;

public enum Amenity {
    WIFI
}
