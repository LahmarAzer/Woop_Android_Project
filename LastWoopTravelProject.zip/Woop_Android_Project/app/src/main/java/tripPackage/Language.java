package tripPackage;

public enum Language {
    ENGLISH
}
